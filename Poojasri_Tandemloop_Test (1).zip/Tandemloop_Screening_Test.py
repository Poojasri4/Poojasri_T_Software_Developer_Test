# ----------------------------
# Problem 1: Calculator using Class
# ----------------------------

class Calculator:
    def __init__(self, a, b):
        self.a = a
        self.b = b

    def operate(self, operation):
        if operation == 'add':
            return self.a + self.b
        elif operation == 'sub':
            return self.a - self.b
        elif operation == 'mul':
            return self.a * self.b
        elif operation == 'div':
            return self.a / self.b if self.b != 0 else "Cannot divide by zero"
        else:
            return "Invalid operation"

print("Problem 1: Calculator Output")
calc = Calculator(10, 5)
print("Addition:", calc.operate("add"))
print("Subtraction:", calc.operate("sub"))
print("Multiplication:", calc.operate("mul"))
print("Division:", calc.operate("div"))
print()

# ----------------------------
# Problem 2: Series of odd numbers up to a given input
# ----------------------------

def generate_series(n):
    return [i for i in range(1, 2 * n, 2)]

print("Problem 2: Odd Number Series")
a = 4  # Example input
print(f"Input a = {a} → Output:", generate_series(a))
print()

# ----------------------------
# Problem 3: Odd series with pattern as per even/odd input
# ----------------------------

def generate_variable_series(n):
    result = []
    for i in range(1, 2*n, 2):
        result.append(i)
        if len(result) >= n:
            break
    return result[:n if n % 2 != 0 else n - 1]

print("Problem 3: Custom Pattern Series")
a = 6  # Example input
print(f"Input a = {a} → Output:", generate_variable_series(a))
print()

# ----------------------------
# Problem 4: Count multiples of 1–9 from a list
# ----------------------------

def count_multiples(lst):
    result = {i: 0 for i in range(1, 10)}
    for number in lst:
        for i in result:
            if number % i == 0:
                result[i] += 1
    return result

print("Problem 4: Count of Multiples")
numbers = [1, 2, 8, 9, 12, 46, 76, 82, 15, 20, 30]
print("Input List:", numbers)
print("Output:", count_multiples(numbers))

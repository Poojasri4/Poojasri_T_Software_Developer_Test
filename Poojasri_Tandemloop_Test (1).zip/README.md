# Tandemloop Screening Test – Poojasri T

**Language Used:** Python

## Problem Descriptions

**Problem 1:** Calculator using Class  
**Problem 2:** Generate odd number series until `x`  
**Problem 3:** Custom pattern odd series  
**Problem 4:** Count multiples of numbers 1 to 9 in a list

## How to Run

Each section is included in one file: `Tandemloop_Screening_Test.py`  
Run it using:
```
python Tandemloop_Screening_Test.py
```
